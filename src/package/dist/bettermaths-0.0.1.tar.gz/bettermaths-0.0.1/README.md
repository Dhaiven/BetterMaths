![alt text](https://github.com/Dhaiven/BetterMaths/blob/main/images/banner.png "Title")


[![GPLv3 License](https://img.shields.io/badge/License-GPL%20v3-yellow.svg)](https://opensource.org/licenses/)
> [!WARNING]
> This module is in beta phase

#### See the [Wiki](https://github.com/Dhaiven/BetterMaths/wiki) for documentations

## Contribution
BetterMaths accepts community contributions!

## Authors
  - <img src="https://www.github.com/Dhaiven.png" width="3%" height="3%" border-radius=100% />  [@Dhaiven](https://www.github.com/Dhaiven) for code
  - <img src="https://www.github.com/algorythmTTV.png" width="3%" height="3%" border-radius=100% />  [@algorythmTTV](https://www.github.com/algorythmTTV) for images and site
